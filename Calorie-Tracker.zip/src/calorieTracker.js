const calculateWeightLostInAMonth = (cycling,running,swimming,extraCalorieInTake) =>{
   let weightLostInAMonth = 0;

   // write logic here 
   if (cycling<=0 || running<=0 || swimming<=0 || extraCalorieInTake<=0) {
      weightLostInAMonth=-1;
   }
   else{
      weightLostInAMonth=(((cycling*8)+(running*8)+(swimming*8))-(extraCalorieInTake*30))/1000;
   }

   return weightLostInAMonth;
   
}

module.exports = calculateWeightLostInAMonth

