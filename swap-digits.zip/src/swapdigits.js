const swapDigits = (number)=>{
    let swappedNumber = 0
    //write logic here
     if(number <= 0){
        return 0
    }
    else {
        var strNum = number.toString();
        var i = 0;
        var strArr
        if(strNum.length % 2 === 0){
            // swap the digits in sets of 2
             strArr = strNum.split('');
             i = 0;
        }
        else {
            // leave the first digit and swap the digits in sets of 2
             strArr = strNum.split('');
             i = 1;
        }
        while(i < strArr.length){
            let temp = strArr[i];
            strArr[i] = strArr[i+1];
            strArr[i+1] = temp;
            i += 2;
        }
        swappedNumber = parseInt(strArr.join(''));
    }
    return swappedNumber;
    
}

module.exports = swapDigits
