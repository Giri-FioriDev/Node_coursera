var category = function category(key) {
  
  // Write the Logic here

}
  
  module.exports = {
    category: category
  };

  var category = function category(key) {
    var key = key.toUpperCase();
    if (key === "EL") {
      return "Education Loan";
    } else if (key === "HL") {
      return "Home Loan";
    } else if (key === "VL") {
      return "Vehicle Loan";
    } else if (key === "PL") {
      return "Personal Loan";
    } else {
      return -1;
    }
  };
  module.exports = {
    category: category
  };