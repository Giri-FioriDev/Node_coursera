var customerList = [];

const addCustomer = (CustomerId, CustomerName, CustomerAge, CustomerAddress, CustomerContactNumber, Category) => {
      // Write the Logic here
      let isAlready = false;

      if (customerList.length == 0) {
            customerList.push([CustomerId, CustomerName, CustomerAge, CustomerAddress, CustomerContactNumber, Category])

      }
      else {
            isAlready = customerList.some(customer => customer[0] === CustomerId);
            if (!isAlready) {
                  customerList.push([CustomerId, CustomerName, CustomerAge, CustomerAddress, CustomerContactNumber, Category]);


            }
      }
}

const updateCustomer = (CustomerId, CustomerName, CustomerAge, CustomerAddress, CustomerContactNumber, Category) => {
      // Write the Logic here
      customerList.filter(customer => {
            if(customer[0] == CustomerId){
                  customer[1] = CustomerName;
                  customer[2] = CustomerAge;
                  customer[3] = CustomerAddress;
                  customer[4] = CustomerContactNumber;
                  customer[5] = Category;
            }
      });


}

const getAllCustomers = () => {
      // Write the Logic here
      return customerList;
}

module.exports = { addCustomer, updateCustomer, getAllCustomers }