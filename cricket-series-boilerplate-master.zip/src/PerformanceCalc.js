
const PerformanceCalculator=(runs,balls)=>{
      // Write the Logic here
      let average = runs / balls;

      if (runs > 100 && balls < 50) {
            average *= 1.20;
      } else if (runs > 50 && balls < 25) {
            average *= 1.10;
      } else if (runs > 30 && balls < 15) {
            average *= 1.01;
      }

      return average;
}

module.exports={PerformanceCalculator}
